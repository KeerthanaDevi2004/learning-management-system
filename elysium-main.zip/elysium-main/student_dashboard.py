import streamlit as st
from pymongo import MongoClient
import subprocess
from PIL import Image
import enrollment
import enrolled
from data_base import mongo_url
# Connect to MongoDB
client = MongoClient(mongo_url)
db = client['Excel']
collection_student = db['students']

with open("student_id.txt", "r") as f:
    student_id = f.read()
    
# Load the image
image = Image.open(r'Icons/23.jpg')

# Display the image
st.image(image, use_column_width=True)


# Retrieve teacher's name from the "teachers" collection
student = collection_student.find_one({"roll_number": student_id})

# Display the teacher's name as the sidebar title
st.sidebar.write(f"Student ID: {student_id}")
st.sidebar.title(f"Welcome: {student['student_name']}")
st.sidebar.write("Select Activity to be performed:")

# Define a dictionary of page names and their corresponding functions
pages = {
    'Enroll in a new course': enrollment,
    'Existing Enrollments': enrolled,
}

# Display clickable headings in the sidebar
selected_page = st.sidebar.radio('', list(pages.keys()))

# Get the selected page function and execute it
selected_page_function = pages[selected_page]
selected_page_function.main()

# Add a "Logged Out" button to log out and navigate back to the homepage
if st.sidebar.button("Log Out"):
    subprocess.run(["streamlit", "run", "homepage.py"], shell=True)

        
