import streamlit as st
import pandas as pd
from PIL import Image


def convert_marks_to_percentage(marks, max_marks):
    return (marks / max_marks) * 100

def convert_to_task_weightage(marks):
    return marks * 0.50

def convert_attendance_to_percentage(attendance):
    return (attendance / 100) * 5

def convert_ontime_submission_to_percentage(submission):
    return submission * 5

def convert_practice_note_to_percentage(note):
    return (note / 5) * 5

def convert_quiz_mark_to_percentage(marks):
    return (marks / 5) * 10

def convert_task2_marks_to_percentage(marks):
    return (marks / 10) * 25

# Upload CSV file and get data
uploaded_file = st.file_uploader("Upload CSV file", type="csv")
if uploaded_file is not None:
    data = pd.read_csv(uploaded_file)

    # Calculate percentages
    data['Task 1 Percentage'] = convert_marks_to_percentage(data['task1'], 10)
    data['Task 1 Weightage'] = convert_to_task_weightage(data['Task 1 Percentage'])
    data['Attendance Percentage'] = convert_attendance_to_percentage(data['attendance'])
    data['On-Time Submission Percentage'] = convert_ontime_submission_to_percentage(data['ontime_submission'])
    data['Practice Note Percentage'] = convert_practice_note_to_percentage(data['practice_note'])
    data['Quiz Mark Percentage'] = convert_quiz_mark_to_percentage(data['quiz'])
    data['Task 2 Percentage'] = convert_task2_marks_to_percentage(data['task2'])

    # Calculate total percentage
    data['points'] = data['Task 1 Weightage'] + data['Attendance Percentage'] + \
                               data['On-Time Submission Percentage'] + data['Practice Note Percentage'] + \
                               data['Quiz Mark Percentage'] + data['Task 2 Percentage']

    # Sort data by total percentage and assign rank
    data = data.sort_values(by='points', ascending=False)
    data['Rank'] = range(1, len(data) + 1)

    # Create clusters based on Task 2 value
    easy_cluster = data[data['task2'] == 0]
    hard_cluster = data[data['task2'] > 0]

    # Separate rankings for easy and hard categories
    easy_cluster = easy_cluster.sort_values(by='points', ascending=False)
    easy_cluster['Easy Rank'] = range(1, len(easy_cluster) + 1)
    hard_cluster = hard_cluster.sort_values(by='points', ascending=False)
    hard_cluster['Hard Rank'] = range(1, len(hard_cluster) + 1)

    st.header("cluster leader board")
    # Display the rest of the data
    st.subheader("Easy Category")
    st.write(easy_cluster[['name','points', 'Easy Rank']])

    st.subheader("Hard Category")
    st.write(hard_cluster[['name', 'points', 'Hard Rank']])