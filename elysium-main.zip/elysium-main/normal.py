import streamlit as st
import pandas as pd

def convert_practice_note_to_percentage(note):
    return (note / 5) * 20

def convert_quiz_mark_to_percentage(marks):
    return (marks / 5) * 30

def convert_weekly_test_to_percentage(weekly_test):
    return (weekly_test / 20) * 50

# CSS styles
css = """
<style>
    .center {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        z-index: 10;
        font-family: 'Red Hat Display', sans-serif;
    }

    .leaderboard {
        padding-left: 2rem;
        margin: 0 auto;
    }

    .item {
        position: relative;
        display: flex;
        align-items: center;
        background: white;
        height: 3rem;
        border-radius: 4rem;
        margin-bottom: 2rem;
        background: navy; /* Updated color to navy blue */
        transform-origin: left;
        cursor: pointer;
        transition: transform 200ms ease-in-out;
        box-shadow:
            0 0 4rem 0 rgba(black, 0.1),
            0 1rem 2rem -1rem rgba(black, 0.3);
    }

    .pos {
        font-weight: 900;
        position: absolute;
        left: -2rem;
        text-align: center;
        font-size: 1.25rem;
        width: 1.5rem;
        color: white;
        opacity: 0.6;
        transition: opacity 200ms ease-in-out;
    }

    .pic {
        width: 4rem;
        height: 4rem;
        border-radius: 50%;
        background-size: cover;
        background-position: center;
        margin-right: 1rem;
        box-shadow:
            0 0 1rem 0 rgba(black, 0.2),
            0 1rem 1rem -0.5rem rgba(black, 0.3);
    }

    .name {
        flex-grow: 2;
        flex-basis: 10rem;
        font-size: 1.1rem;
        color: white; /* Set font color to white */
    }

    .score {
        margin-right: 1.5rem;
        opacity: 0.5;
        color: white !important; /* Set font color to white */
    }

    .item:hover {
        transform: scale(1.05);
    }

    .item:hover .pos {
        opacity: 0.8;
    }
</style>
"""

# Apply CSS styles
st.markdown(css, unsafe_allow_html=True)

# Upload CSV file and get data
uploaded_file = st.file_uploader("Upload CSV file", type="csv")
if uploaded_file is not None:
    data = pd.read_csv(uploaded_file)

    # Calculate percentages
    data['Practice Note Percentage'] = convert_practice_note_to_percentage(data['practice_note'])
    data['Quiz Mark Percentage'] = convert_quiz_mark_to_percentage(data['quiz'])
    data['Weekly Test Percentage'] = convert_weekly_test_to_percentage(data['weekly_test'])

    # Calculate total points
    data['points'] = data['Practice Note Percentage'] + data['Quiz Mark Percentage'] + data['Weekly Test Percentage']

    # Sort data by points and assign rank
    data = data.sort_values(by='points', ascending=False)
    data['rank'] = range(1, len(data) + 1)

    st.header("Normal Leaderboard")

    # Display the leaderboard
    for index, row in data.iterrows():
        st.markdown(f"<div class='item'><div class='pos'>{row['rank']}</div><div class='pic'></div><div class='name'>{row['name']}</div><div class='score'>{int(row['points'])}</div></div>", unsafe_allow_html=True)