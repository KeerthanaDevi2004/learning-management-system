import streamlit as st
from pymongo import MongoClient
import subprocess
import pandas as pd
import sys
from PIL import Image
from data_base import mongo_url

def main():
    # Connect to MongoDB
    client = MongoClient(mongo_url)
    db = client['Excel']
    collection = db['course_creations']
    
     # Load the image
    image = Image.open(r'Icons/27.jpg')

    # Display the image
    st.image(image, use_column_width=True)

    with open("employee_id.txt", "r") as f:
        employee_id = f.read()

    # Display the employee ID as a heading
    st.write("Employee ID: " + employee_id)

    # Get courses created by the respective employee ID
    courses = list(collection.find({"employee_id": employee_id}))

    # Fetch existing courses
    existing_courses = list(collection.find({"employee_id": employee_id}))

    # Display existing courses
    if existing_courses:
        st.title("Existing Courses")

        # Create a DataFrame for the courses
        df = pd.DataFrame(existing_courses)

        # Set the column order as desired
        columns = ["course_id", "course_name", "course_description"]

        # Display the table with Edit button
        for index, row in df.iterrows():
            st.subheader(f"Course Name: {row['course_name']}")
            st.write(f"Course ID: {row['course_id']}")
            st.write(f"Course Description: {row['course_description']}")
            if st.button(f"Edit {row['course_name']}", key=f"edit_button_{index}"):
                with open("course_id.txt", "w") as f:
                    f.write(row['course_id'])
                subprocess.run(["streamlit", "run", "activity.py"], shell=True)
                sys.exit(0)  # Stop script execution

            st.write("------")

    else:
        st.write("No existing courses found.")
        
    st.image(image, use_column_width=True)
    

if __name__ == "__main__":
    main()
