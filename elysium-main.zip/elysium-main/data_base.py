import streamlit as st
from pymongo import MongoClient
from PIL import Image


# Access the MongoDB connection details from the TOML file
MONGO_USERNAME = st.secrets["MONGO_USERNAME"]
MONGO_PASSWORD = st.secrets["MONGO_PASSWORD"]
MONGO_HOSTNAME = st.secrets["MONGO_HOSTNAME"]

# Create the MongoDB connection URL
mongo_url = f"mongodb+srv://{MONGO_USERNAME}:{MONGO_PASSWORD}@{MONGO_HOSTNAME}/?retryWrites=true&w=majority"

