import streamlit as st
import pandas as pd
from pymongo import MongoClient
from data_base import mongo_url

def highlight_row(row, roll_number):
    if row['roll_number'] == roll_number:
        return ['background-color: grey'] * len(row)
    else:
        return [''] * len(row)

def main():
    client = MongoClient(mongo_url)
    db = client['Excel']
    collection = db['normal_leaderboard']

    

    st.header("Normal Leaderboard")

    # Retrieve available from dates from the database
    available_dates = list(collection.distinct("from_date"))

    # Dropdown menu for selecting from date
    selected_date = st.selectbox("Select From Date", available_dates)

    # Retrieve leaderboard data from MongoDB based on selected from date
    query = {"from_date": selected_date}
    leaderboard_data = pd.DataFrame(list(collection.find(query)))

    # Read the roll number from the text file
    with open("student_id.txt", "r") as file:
        roll_number = file.read().strip()

    # Display the leaderboard table with highlighted row
    st.table(leaderboard_data[['roll_number', 'name', 'points', 'rank']].style.apply(highlight_row, roll_number=roll_number, axis=1))
    

if __name__ == "__main__":
    main()
