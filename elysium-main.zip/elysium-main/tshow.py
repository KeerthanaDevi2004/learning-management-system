import streamlit as st
import pandas as pd
from pymongo import MongoClient
from data_base import mongo_url

def highlight_row(row):
    styles = [''] * len(row)  # Default styles for all cells
    
    if row['rank'] == 1:
        styles = ['background-color: #8B8B8B'] * len(row)  # Highlight rank 1 with yellow
    
    elif row['rank'] == 2:
        styles = ['background-color: #737373'] * len(row)  # Highlight rank 2 with light blue
    
    elif row['rank'] == 3:
        styles = ['background-color: #545454'] * len(row)  # Highlight rank 3 with light green
    
    return styles

def main():
    client = MongoClient(mongo_url)
    db = client['Excel']
    collection = db['normal_leaderboard']

    st.header("Normal Leaderboard")

    # Retrieve available from dates from the database
    available_dates = list(collection.distinct("from_date"))

    # Dropdown menu for selecting from date
    selected_date = st.selectbox("Select From Date", available_dates)

    # Retrieve leaderboard data from MongoDB based on selected from date
    query = {"from_date": selected_date}
    leaderboard_data = pd.DataFrame(list(collection.find(query)))

    # Display the leaderboard table with highlighted rows
    st.table(leaderboard_data[['roll_number','name', 'points', 'rank']].style.apply(highlight_row, axis=1))

if __name__ == "__main__":
    main()
