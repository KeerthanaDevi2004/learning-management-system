import streamlit as st
import pandas as pd

# Function to convert weekly test mark to percentage
def convert_weekly_test_to_percentage(weekly_test):
    return int((weekly_test / 20) * 70)

# Function to convert practice note mark to percentage
def convert_practice_note_to_percentage(practice_note):
    return int((practice_note / 5) * 30)

# CSS styles
css = """
<style>
    .item {
        position: relative;
        display: flex;
        align-items: center;
        background: navy;
        height: 3rem;
        border-radius: 4rem;
        margin-bottom: 2rem;
        background: navy;
        transform-origin: left;
        cursor: pointer;
        transition: transform 200ms ease-in-out;
        box-shadow:
            0 0 4rem 0 rgba(black, 0.1),
            0 1rem 2rem -1rem rgba(black, 0.3);
    }

    .pos {
        font-weight: 900;
        position: absolute;
        left: -2rem;
        text-align: center;
        font-size: 1.25rem;
        width: 1.5rem;
        color: white;
        opacity: 0.6;
        transition: opacity 200ms ease-in-out;
    }

    .pic {
        width: 4rem;
        height: 4rem;
        border-radius: 50%;
        background-size: cover;
        background-position: center;
        margin-right: 1rem;
        box-shadow:
            0 0 1rem 0 rgba(black, 0.2),
            0 1rem 1rem -0.5rem rgba(black, 0.3);
    }

    .name {
        flex-grow: 2;
        flex-basis: 10rem;
        font-size: 1.1rem;
        color: white;
    }

    .score {
        margin-right: 1.5rem;
        opacity: 0.5;
        color: white !important;
    }

    .item:hover {
        transform: scale(1.05);
    }

    .item:hover .pos {
        opacity: 0.8;
    }
</style>
"""

uploaded_file = st.file_uploader("Upload CSV file", type="csv", help="Please upload a CSV file.")
if uploaded_file is not None:
    data = pd.read_csv(uploaded_file)

    # Convert weekly test mark to percentage
    data['Weekly Test Percentage'] = data['weekly_test'].apply(convert_weekly_test_to_percentage)

    # Convert practice note mark to percentage
    data['Practice Note Percentage'] = data['practice_note'].apply(convert_practice_note_to_percentage)

    # Calculate group points
    group_data = data.groupby('group name').agg({'Weekly Test Percentage': 'sum', 'Practice Note Percentage': 'sum'}).reset_index()
    group_data['group points'] = group_data['Weekly Test Percentage'] + group_data['Practice Note Percentage']

    # Assign group rank based on group points
    group_data = group_data.sort_values(by='group points', ascending=False).reset_index(drop=True)
    group_data['group rank'] = range(1, len(group_data) + 1)

    # Display the from_date and to_date
    from_date = data['from_date'].iloc[0]
    to_date = data['to_date'].iloc[0]
    st.write(f"From: {from_date}   To: {to_date}")

    # Apply CSS styles
    st.markdown(css, unsafe_allow_html=True)

    # Display the group leaderboard
    for index, row in group_data.iterrows():
        st.markdown(
            f"""
            <div class="item">
                <div class="pos">{row['group rank']}</div>
                <div class="pic"></div>
                <div class="name">{row['group name']}</div>
                <div class="score">{row['group points']} points</div>
            </div>
            """,
            unsafe_allow_html=True
        )
