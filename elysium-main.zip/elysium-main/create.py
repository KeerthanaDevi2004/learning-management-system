import streamlit as st
from pymongo import MongoClient
from PIL import Image
from data_base import mongo_url

# Connect to MongoDB
client = MongoClient(mongo_url)
db = client["Excel"]
collection = db["course_creations"]

def create_course():
    
    # Load the image
    image = Image.open(r'Icons/23.jpg')

    # Display the image
    st.image(image, use_column_width=True)
    
    st.subheader("Create your course by filling in the required details")
    course_form = st.form(key='course_form', clear_on_submit=True)
    # Input fields for course details
    employee_id = course_form.text_input("Enter employee ID", key='employee_id')
    course_id = course_form.text_input("Enter course ID", key='course_id')
    course_name = course_form.text_input("Enter course name", key='course_name')
    course_description = course_form.text_input("Enter course description", key='course_description')
    leaderboard_type = course_form.selectbox("Select leaderboard type", 
                                             ["Cluster leaderboard", "Normal leaderboard", "Group leaderboard"],
                                             key='leaderboard_type')

    submit_button = course_form.form_submit_button("Submit")
    
    

    if submit_button:
        # Validate and process the input
        if employee_id and course_id and course_name and course_description and leaderboard_type:
            # Store the course in MongoDB
            course = {
                "employee_id": employee_id,
                "course_id": course_id,
                "course_name": course_name,
                "course_description": course_description,
                "leaderboard_type": leaderboard_type
            }
            collection.insert_one(course)
            st.success("Course created successfully and stored in the database!")
        else:
            st.error("Please fill in all the details.")

# Main function
def main():
    create_course()

if __name__ == "__main__":
    main()
