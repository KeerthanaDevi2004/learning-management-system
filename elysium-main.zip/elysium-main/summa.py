import streamlit as st
def main():
    # Set the page title
    st.title("Please wait... Updates are to be done")

if __name__ == "__main__":
    main()
