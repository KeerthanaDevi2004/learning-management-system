import streamlit as st
from pymongo import MongoClient
import subprocess
from data_base import mongo_url

# Connect to MongoDB
client = MongoClient(mongo_url)
db = client["Excel"]
enrollment_collection = db["enrollment"]
course_collection = db["course_creations"]

def main():
    
    with open("student_id.txt", "r") as f:
        roll_number = f.read()

    st.write
    (f"Student roll number: {roll_number}")

    # Fetch enrolled courses for the student roll number
    enrollments = list(enrollment_collection.find({"roll_number": roll_number}))

    # Display existing enrollments
    if enrollments:
        st.subheader("Existing Enrollments")

        for enrollment in enrollments:
            course_id = enrollment["course_id"]
            course_info = course_collection.find_one({"course_id": course_id})
            if course_info:
                st.write(f"Course ID: {course_info['course_id']}")
                st.write(f"Course Name: {course_info['course_name']}")
                st.write(f"Course Description: {course_info['course_description']}")

                # Add "View Course Activities" button
                view_activities_button = st.button(f"View Course Activities: {course_info['course_name']}")
                
                # Set the course_id in session state
                st.session_state.course_id = course_id

                # Save the course_id in a file
                with open("course_id.txt", "w") as f:
                    f.write(course_id)
                
                if view_activities_button:
                    subprocess.run(["streamlit", "run", "student_activity.py"], shell=True)

                st.write("------")
    else:
        st.write("No existing enrollments found.")
        
        
if __name__ == "__main__":
    main()


