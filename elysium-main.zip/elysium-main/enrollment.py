import streamlit as st
from pymongo import MongoClient
from data_base import mongo_url

# Connect to MongoDB
client = MongoClient(mongo_url)
db = client["Excel"]
enrollment_collection = db["enrollment"]
course_collection = db["course_creations"]


def get_student_roll_number():
    try:
        with open("student_id.txt", "r") as file:
            roll_number = file.read().strip()
            return roll_number
    except FileNotFoundError:
        return None


def enrollment_page():
    st.title("Enrollment")
    st.write("Please enter the following details to enroll in a course:")

    enrollment_form = st.form(key='enrollment_form', clear_on_submit=True)
    student_id = enrollment_form.text_input("Enter Student Roll Number",
                                            value=get_student_roll_number())
    course_id = enrollment_form.text_input("Enter course ID")

    enroll_button = enrollment_form.form_submit_button("Enroll")

    if enroll_button:
        if student_id and course_id:
            # Check if the course_id exists in course_creations collection
            if course_collection.find_one({"course_id": course_id}):
                enrollment_data = {
                    "roll_number": student_id,
                    "course_id": course_id,
                }
                enrollment_collection.insert_one(enrollment_data)
                st.success("Enrollment successful! Details saved to the database.")
            else:
                st.error("Course ID not found.")
        else:
            st.error("Please fill in all the required fields.")


# Main function
def main():
    enrollment_page()


if __name__ == "__main__":
    main()
