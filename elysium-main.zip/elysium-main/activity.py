import streamlit as st
from pymongo import MongoClient
import normal_leaderboard
import tshow
import summa
from PIL import Image
from data_base import mongo_url

# Connect to MongoDB
client = MongoClient(mongo_url)
db = client['Excel']
collection_course = db['course_creations']

# Load the image
image = Image.open(r'Icons/23.jpg')

# Display the image
st.image(image, use_column_width=True)


with open("course_id.txt", "r") as f:
    course_id = f.read()

# Retrieve course details from the "course_creations" collection
course = collection_course.find_one({"course_id": course_id})

# Check if the course exists
if course:
    # Display the course ID and name as the sidebar title
    st.sidebar.write(f"Course ID: {course_id}")
    st.sidebar.title(f"Editing Course : {course['course_name']}")

    # Define the activity titles
    pages = {
        "Upload Test Scores": normal_leaderboard,
        "View Leaderboard": tshow,
        "Create Quiz": summa,
        "Create Assignment": summa,
        "Announcements": summa,
        "Learning Materials": summa,
        "View Enrollments": summa,
        "Feedback": summa,
    }

    # Display clickable headings in the sidebar
    selected_page = st.sidebar.radio('', list(pages.keys()))

    # Get the selected page function and execute it
    selected_page_function = pages[selected_page]
    selected_page_function.main()
else:
    st.sidebar.write("Course not found")
