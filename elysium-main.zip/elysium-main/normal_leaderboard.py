import streamlit as st
import pandas as pd
from pymongo import MongoClient
from data_base import mongo_url

def convert_practice_note_to_percentage(note):
    return (note / 5) * 20

def convert_quiz_mark_to_percentage(marks):
    return (marks / 5) * 30

def convert_weekly_test_to_percentage(weekly_test):
    return (weekly_test / 20) * 50

def main():
    # Connect to MongoDB
    client = MongoClient(mongo_url)
    db = client['Excel']
    collection = db['normal_leaderboard']

    # Upload CSV file and get data
    uploaded_file = st.file_uploader("Upload CSV file", type="csv", accept_multiple_files=True)
    if uploaded_file is not None:
        for file in uploaded_file:
            data = pd.read_csv(file)

            # Calculate percentages
            data['Practice Note Percentage'] = convert_practice_note_to_percentage(data['practice_note'])
            data['Quiz Mark Percentage'] = convert_quiz_mark_to_percentage(data['quiz'])
            data['Weekly Test Percentage'] = convert_weekly_test_to_percentage(data['weekly_test'])

            # Calculate total points
            data['points'] = data['Practice Note Percentage'] + data['Quiz Mark Percentage'] + data['Weekly Test Percentage']

            # Sort data by points and assign rank
            data = data.sort_values(by='points', ascending=False)
            data['rank'] = range(1, len(data) + 1)

            # Store data in MongoDB
            leaderboard_data = data.to_dict('records')

            # Check if data already exists in the collection
            if leaderboard_data:
                existing_data = collection.find({"from_date": leaderboard_data[0]["from_date"]})
                existing_records = [record for record in existing_data]
                if existing_records:
                    existing_ids = [record["_id"] for record in existing_records]
                    collection.delete_many({"_id": {"$in": existing_ids}})

            collection.insert_many(leaderboard_data)
            st.success("CSV Uploaded successfully!")
            
if __name__ == "__main__":
    main()


    