import streamlit as st
from pymongo import MongoClient
from PIL import Image
import show
import summa
from data_base import mongo_url
# Connect to MongoDB
client = MongoClient(mongo_url)
db = client['Excel']
collection_course = db['course_creations']

with open("student_id.txt", "r") as f:
    student_id = f.read() 

st.sidebar.write(f"Student ID: {student_id}")

with open("course_id.txt", "r") as f:
    course_id = f.read()
    
    # Load the image
image = Image.open(r'Icons/26.jpg')

# Display the image
st.image(image, use_column_width=True)

    
# Retrieve course details from the "course_creations" collection
course = collection_course.find_one({"course_id": course_id})

st.sidebar.write(f"Course Id: {course_id} ")
st.sidebar.title(f"Viewing Course Activities : {course['course_name']}")
    


# Retrieve course details from the "course_creations" collection
course = collection_course.find_one({"course_id": course_id})

# Check if the course exists
if course:
    # Activity titles and corresponding Python files
    pages = {
        "View Leaderboard": show,
        "Quiz": summa,
        "Attendance": summa,
        "Assignments": summa,
        "Learning Materials": summa,
        "Announcements": summa,
        "Feedback": summa
    }

    # Display clickable headings in the sidebar
    selected_page = st.sidebar.radio('', list(pages.keys()))

    # Get the selected page function and execute it
    selected_page_function = pages[selected_page]
    selected_page_function.main()
else:
  st.sidebar.write("Course not found")
