import streamlit as st
from PIL import Image
from pymongo import MongoClient
import subprocess
import os
from data_base import mongo_url
# Connect to MongoDB
client = MongoClient(mongo_url)
db = client['Excel']
student_collection = db["students"]
teacher_collection = db["teachers"]

if 'form' not in st.session_state:
    st.session_state.form = ''

def student_signup():
    st.session_state.form = 'student_signup_form'

def teacher_signup():
    st.session_state.form = 'teacher_signup_form'
    
def student_login():
    st.session_state.form = 'student_login_form'
    
def teacher_login():  
    st.session_state.form = 'teacher_login_form'
    
def main():
    st.title("Welcome to Elysium!")
    st.write("Please select your mode:")
    # Load profile pictures
    student_image = Image.open(r'Icons/1.jpg')
    teacher_image = Image.open(r'Icons/2.jpg')

    col1, col2 = st.columns(2)
    
    with col1:
        student_selected = st.image(student_image, caption="Welcome Buddy", use_column_width=True)
        student_signup_selected = st.button("Student Sign Up")
        student_login_selected = st.button("Student Login")
        if student_signup_selected:
            student_signup()
        elif student_login_selected:
            student_login()

    with col2:
        teacher_selected = st.image(teacher_image, caption="Welcome Teacher", use_column_width=True)
        teacher_signup_selected = st.button("Teacher Sign Up")
        teacher_login_selected = st.button("Teacher Login")
        if teacher_signup_selected:
            teacher_signup()
        elif teacher_login_selected:
            teacher_login()

    if st.session_state.form == 'student_signup_form':
        student_signup_page()

    elif st.session_state.form == 'teacher_signup_form':
        teacher_signup_page()

    elif st.session_state.form == 'student_login_form':            
        student_login_page()
                    
    elif st.session_state.form == 'teacher_login_form':  
        teacher_login_page()

def student_signup_page():
    st.title("Student Sign Up")
    st.write("Please enter your details:")
    student_signup_form = st.form(key='student_signup_form', clear_on_submit=True)
    roll_number = student_signup_form.text_input("Enter roll number")
    register_number = student_signup_form.text_input("Enter register number")
    department = student_signup_form.text_input("Enter department")
    student_name = student_signup_form.text_input("Enter student name")
    email = student_signup_form.text_input("Enter email ID")
    password = student_signup_form.text_input("Enter password", type="password")
    confirm_password = student_signup_form.text_input("Confirm password", type="password")

    submit_button = student_signup_form.form_submit_button(label='Sign Up')
    return_button = st.button("Return")

    if submit_button:
        if not roll_number or not register_number or not department or not student_name or not email or not password or not confirm_password:
            st.error("Please fill in all the fields.")
        elif password != confirm_password:
            st.error("Passwords do not match.")
        else:
            # Check for unique roll number and register number
            existing_student = student_collection.find_one({"$or": [{"roll_number": roll_number}, {"register_number": register_number}]})
            if existing_student:
                st.error("Roll number or register number already exists.")
            else:
                user_data = {
                    "roll_number": roll_number,
                    "register_number": register_number,
                    "department": department,
                    "student_name": student_name,
                    "email": email,
                    "password": password
                }
                student_collection.insert_one(user_data)
                st.success("Sign up successful!")
                st.write("Please click on student login to login and continue")

    if return_button:
        st.session_state.form = ''

def teacher_signup_page():
    st.title("Teacher Sign Up")
    st.write("Please enter your details:")
    teacher_signup_form = st.form(key='teacher_signup_form', clear_on_submit=True)
    employee_id = teacher_signup_form.text_input("Enter employee ID")
    teacher_name = teacher_signup_form.text_input("Enter teacher name")
    email = teacher_signup_form.text_input("Enter email ID")
    department = teacher_signup_form.text_input("Enter department")
    designation = teacher_signup_form.text_input("Enter designation")
    password = teacher_signup_form.text_input("Enter password", type="password")

    submit_button = teacher_signup_form.form_submit_button(label='Sign Up')
    return_button = st.button("Return")

    if submit_button:
        if not employee_id or not teacher_name or not email or not department or not designation or not password:
            st.error("Please fill in all the fields.")
        else:
            # Check for unique employee ID
            existing_teacher = teacher_collection.find_one({"employee_id": employee_id})
            if existing_teacher:
                st.error("Employee ID already exists.")
            else:
                user_data = {
                    "employee_id": employee_id,
                    "teacher_name": teacher_name,
                    "email": email,
                    "department": department,
                    "designation": designation,
                    "password": password
                } 
                teacher_collection.insert_one(user_data)
                st.success("Sign up successful!")
                st.write("Please click on teacher login to login and continue")

    if return_button:
        st.session_state.form = ''

def student_login_page():
    st.title("Student Login")
    st.write("Please enter your login details:")

    form = st.form(key='student_login_form')
    roll_number = form.text_input("Enter roll number", key="student_roll_number")
    password = form.text_input("Enter password", type="password", key="student_password")

    submit_button = form.form_submit_button(label='Login')
    return_button = st.button("Return")

    if submit_button:
        user = student_collection.find_one({"roll_number": roll_number})
        if user:
            if user["password"] == password:
                st.success("Login successful!")
                student_name = user["student_name"]
                st.write(f"Welcome, {student_name}!")

                # Set the employee_id in session state
                st.session_state.student_id = roll_number

                # Save the employee_id in a file
                with open("student_id.txt", "w") as f:
                    f.write(roll_number)

                # Navigate to teacher_dashboard.py using os.system()
                os.system("streamlit run student_dashboard.py")
            else:
                st.error("Invalid password.")
        else:
            st.error("User not found.")

    if return_button:
        st.session_state.form = ''



def teacher_login_page():
    st.title("Teacher Login")
    st.write("Please enter your login details:")
    
    with st.form(key='teacher_login_form'):
        employee_id = st.text_input("Enter employee ID", key="teacher_login_id")
        password = st.text_input("Enter password", type="password", key="teacher_login_password")

        submit_button = st.form_submit_button(label='Login')

    return_button = st.button("Return")

    if submit_button:
        user = teacher_collection.find_one({"employee_id": employee_id})
        if user:
            if user["password"] == password:
                st.success("Login successful!")
                teacher_name = user["teacher_name"]
                st.write(f"Welcome, {teacher_name}!")

                # Set the employee_id in session state
                st.session_state.employee_id = employee_id

                # Save the employee_id in a file
                with open("employee_id.txt", "w") as f:
                    f.write(employee_id)

                # Navigate to teacher_dashboard.py using os.system()
                os.system("streamlit run teacher_dashboard.py")
            else:
                st.error("Invalid password.")
        else:
            st.error("User not found.")

    if return_button:
        st.session_state.form = ''

if __name__ == '__main__':
    main()
