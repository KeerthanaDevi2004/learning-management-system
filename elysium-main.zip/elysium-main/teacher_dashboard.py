import streamlit as st
from pymongo import MongoClient
import create
import exist
import subprocess
from data_base import mongo_url

# Connect to MongoDB
client = MongoClient(mongo_url)
db = client['Excel']
collection_teachers = db['teachers']

with open("employee_id.txt", "r") as f:
    employee_id = f.read()

# Retrieve teacher's name from the "teachers" collection
teacher = collection_teachers.find_one({"employee_id": employee_id})

# Display the teacher's name as the sidebar title
st.sidebar.write(f"Employee ID: {employee_id}")
st.sidebar.title(f"Welcome: {teacher['teacher_name']}")
st.sidebar.write("Select Activity to be performed:")

# Define a dictionary of page names and their corresponding functions
pages = {
    'Create a new course': create,
    'Edit & View Existing Courses': exist,
}

# Display clickable headings in the sidebar
selected_page = st.sidebar.radio('', list(pages.keys()))

# Get the selected page function and execute it
selected_page_function = pages[selected_page]
selected_page_function.main()

# Add a "Logged Out" button to log out and navigate back to the homepage
if st.sidebar.button("Log Out"):
    subprocess.run(["streamlit", "run", "homepage.py"], shell=True)
